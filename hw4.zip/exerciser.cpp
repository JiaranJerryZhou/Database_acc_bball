#include "exerciser.h"

void exercise(connection *C) {
  /*
  add_color(C, "Blue");
  add_state(C, "Shanghai");
  add_team(C, "Shanghai Jiao Tong University", 11, 9, 15, 0);
  add_player(C, 16, 7, "Jiaran", "Zhou", 40, 30, 10, 10, 5, 5);
  cout << "all players with 35 to 40 mpg:" << endl;
  */
  query1(C, 1, 35, 40, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0);
  /*
  cout << endl;
  cout << "all teams with red uniform:" << endl;
  query2(C, "Red");
  cout << endl;
  cout << "all players from Duke:" << endl;
  query3(C, "Duke");
  cout << endl;
  cout << "all players from NC and wear red uniform:" << endl;
  query4(C, "NC", "Red");
  cout << endl;
  cout << "all players and their teams that win more than 10 games:" << endl;
  query5(C, 10);
  cout << "all teams with blue uniform:" << endl;
  query2(C, "Blue");
  cout << endl;
  cout << "all players from Shanghai Jiao Tong University:" << endl;
  query3(C, "Shanghai Jiao Tong University");
  cout << endl;
  cout << "all players from Shanghai and wear blue uniform:" << endl;
  query4(C, "Shanghai", "Blue");
  cout << endl;
  */
}
